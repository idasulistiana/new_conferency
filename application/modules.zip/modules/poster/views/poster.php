
	<div id="body">
	<div class="clearfix"></div>
		<div class="section">
			<h2 align="center"><br>Poster</h2>
				
				<img src="<?php echo base_url()?>assets/images/call_paper.png" class="img_call_paper">
			<br>
			<br>
		</div>
	</div> 