
	<div id="body">
	<div class="clearfix"></div>
		<div class="section">
			<h2>Awards</h2>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in vestibulum mi. Donec felis nunc, placerat quis varius quis, posuere sed velit. In convallis pulvinar rutrum. Suspendisse nec mi lectus, at fermentum felis.
				Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in vestibulum mi. Donec felis nunc, placerat quis varius quis, posuere sed velit. In convallis pulvinar rutrum. Suspendisse nec mi lectus, at fermentum felis.
			</p>
			<div class="border">
				<img src="<?php echo base_url() ;?>assets/images/sponsor.jpg" alt="">
				<div >
					<b><a href="#">Awards 1</a></b> <small>internal medicine doctor consultant</small>
					<p>
						Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in vestibulum mi. Donec felis nunc, placerat quis varius quis, posuere sed velit. In convallis pulvinar rutrum. Suspendisse nec mi lectus, at fermentum felis.
					</p>
				</div>
			</div>
			<div class="border">
				<img src="<?php echo base_url() ;?>assets/images/sponsor.jpg" alt="">
				<div >
					<b><a href="#">Awards 2</a></b> <small>internal medicine doctor consultant</small>
					<p>
					Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in vestibulum mi. Donec felis nunc, placerat quis varius quis, posuere sed velit. In convallis pulvinar rutrum. Suspendisse nec mi lectus, at fermentum felis.
					</p>
				</div>
			</div>
			<div class="border">
				<img src="<?php echo base_url() ;?>assets/images/sponsor.jpg" alt="">
				<div >
					<b><a href="#">Awards 3</a></b> <small>internal medicine doctor consultant</small>
					<p>
					Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in vestibulum mi. Donec felis nunc, placerat quis varius quis, posuere sed velit. In convallis pulvinar rutrum. Suspendisse nec mi lectus, at fermentum felis.
					</p>
				</div>
			</div>

		</div>
	</div>