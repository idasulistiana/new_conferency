<div id="body">
	<div class="content">
		<div class="col-md-5"> Welcome <?php echo $this->session->userdata('username') ?></div>
	</div>
</div>