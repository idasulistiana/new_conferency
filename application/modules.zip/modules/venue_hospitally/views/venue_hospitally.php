
	<div id="body">
	<div class="clearfix"></div>
		<div class="section">
		<h2 align="center"><br>Venue</h2>
			<img src="<?php echo base_url();?>assets/images/logo_hotelsalak1.png" class="img_hotelsalak">
			<span class="text_abouthotel">
				<p align="justify">
					The new luxury tallest hotel in Bogor. The height of the hotel top is about 375 m above sea level.
				Viewing the beauty of Bogor city is only from Salak Tower Hotel.Salak Tower Hotel (STH) has 2 floors of meeting room complex.
				Every floor has 5 meeting rooms with the capacity of 30 persons each. All meeting rooms in one floor can be wide opened to be one large meeting space with the capacity of about 150 persons.
				Has Sky Line Ball Room located on the top of the building viewing sky of Bogor city. Check this website <a href="https://www.salaktowerhotel.com"><u>www.salaktowerhotel.com</u></a><br/>
				</p>
			</span>
			<span class="text_venue">
				The international conference will be held:<br/>
				On	: Monday-Tuesday, October 10-11, 2016<br/>
				Venue	: Salak Tower Hotel,<br/>
				Jl. Salak No. 38-40, Bogor 16121, Indonesia<br/>
				Website: <a href="https://www.salaktowerhotel.com"><u>www.salaktowerhotel</u></a><br/>
				Phone : (0251) 7565111
			</span>
			<br/><br/>
			<img src="<?php echo base_url();?>assets/images/logo_peta_hotel1.png" class="img_hotelsalak">
			<p>
		</div>
	</div> 