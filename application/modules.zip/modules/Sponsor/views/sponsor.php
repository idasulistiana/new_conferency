
	<div id="body">
	<div class="clearfix"></div>
		<div class="section">
			<h2>Sponsor</h2>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in vestibulum mi. Donec felis nunc, placerat quis varius quis, posuere sed velit. In convallis pulvinar rutrum. Suspendisse nec mi lectus, at fermentum felis.
				Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in vestibulum mi. Donec felis nunc, placerat quis varius quis, posuere sed velit. In convallis pulvinar rutrum. Suspendisse nec mi lectus, at fermentum felis.
			</p>
			<ul class="sponsor_img">
				<li class="sponsore">
					<img src="<?php echo base_url() ;?>assets/images/ikabi_logo.jpg" class="img_sponsor">
				</li>
			</ul>
		</div>
		<div class="section">
			<h2>Co Organazier</h2>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in vestibulum mi. Donec felis nunc, placerat quis varius quis, posuere sed velit. In convallis pulvinar rutrum. Suspendisse nec mi lectus, at fermentum felis.
				Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in vestibulum mi. Donec felis nunc, placerat quis varius quis, posuere sed velit. In convallis pulvinar rutrum. Suspendisse nec mi lectus, at fermentum felis.
			</p>
			<ul class="sponsor_img">
				<li class="sponsore">
					<img src="<?php echo base_url() ;?>assets/images/Ristekdikti_logo.jpg" class="img_sponsor">
				</li>
			</ul>
		</div>
	</div>