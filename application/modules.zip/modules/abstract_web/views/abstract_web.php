
	<div id="body">
	<div class="clearfix"></div>
		<div class="section">
			<h2 align="center"><br>Abstract</h2>
				<p align="justify">
				
				If you want to submit your abstract please <a href="https://www.easychair.org/account/signin.cgi?fail=1">click this</a>
				</p>
			<br>
			<br>
			<div class="empty_space">
			</div>
		</div>
	</div> 