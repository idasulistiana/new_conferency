<script type="text/javascript" src="<?php echo base_url() ;?>assets/bootstrap/js/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="<?php echo base_url() ;?>assets/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url() ;?>assets/js/chart.min.js"></script>
<script type="text/javascript" src="<?php echo base_url() ;?>assets/js/admin_js.js"></script>
<script type="text/javascript" src="<?php echo base_url() ;?>assets/js/jquery.dataTables.js"></script>